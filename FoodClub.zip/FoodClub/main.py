from tkinter import *
from tkinter import messagebox
from sqlalchemy import create_engine, Column, String, TEXT, Integer
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import session, sessionmaker

engine = create_engine("sqlite:///foodclubdb.db", echo=True)
Base = declarative_base()
Sessions = sessionmaker(bind=engine)

sessinon = Sessions()


class food(Base):
    __tablename__ = "food"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    family = Column(String)

    def __init__(self, name="", how=""):
        self.name = name
        self.how = how


class Repository():
    def Add(self, obj):
        sessinon.add(obj)
        sessinon.commit()

    def selectAll(self, obj):
        result = sessinon.query(obj).all()
        return result

    def selectById(self, obj, id):
        result = sessinon.query(obj).filter(obj.id == id).first()
        return result

    def showObj(self, list, index):
        for item in list:
            atr = getattr(item, index)
            print(atr)

    def update(self, id, object, **kwargs):
        record = self.selectById(object, id)
        for key, val in kwargs.items():
            setattr(record, key, val)
        sessinon.commit()

    def delete(self, id, object):
        record = self.selectById(object, id)
        sessinon.delete(record)
        sessinon.commit()


Base.metadata.create_all(engine)

repos = Repository()




screen = Tk()

screen.geometry("%dx%d+%d+%d" % (500, 300, 150, 100))
screen.title("FoodClub   1.0.0")
screen.resizable(False, False)
screen.iconbitmap("icon.ico")



def serv():
    n = namev.get()
    p = pizzav.get()
    b = burgerv.get()
    s = saladv.get()
    pa = pastav.get()
    san = sandwichv.get()
    
    pizza = p * 200
    burger = b * 150
    salad = s * 100
    pasta = pa * 100
    sandwich = san * 150

    h = food(name="pizza", how=p)
    repos.Add(h)

    h = food(name="burger", how=b)
    repos.Add(h)

    h = food(name="salad", how=s)
    repos.Add(h)

    h = food(name="pasta", how=pa)
    repos.Add(h)

    h = food(name="sandwich", how=san)
    repos.Add(h)
    sefaresh = pizza + burger + salad + pasta + sandwich
    message = str(sefaresh) + " payed by " + n + " :)"
    messagebox.showinfo("bill", message)


namev = StringVar()
namelbl = Label(screen, text = "name: ", font = "10")
namelbl.place(x = 10, y = 10)
nameetr = Entry(screen, textvariable = namev)
nameetr.place(x = 60, y = 10)


phonev = IntVar()
phonelbl = Label(screen, text = "phone: ", font = "10")
phonelbl.place(x = 10, y = 40)
phoneetr = Entry(screen, textvariable = phonev)
phoneetr.place(x = 60, y = 40)

burgerv = IntVar()
burgerlbl = Label(screen, text = "t150 burger: ", font = "10")
burgerlbl.place(x = 10, y = 70)
burgeretr = Entry(screen, textvariable = burgerv)
burgeretr.place(x = 100, y = 70)

pizzav = IntVar()
pizzalbl = Label(screen, text = "t200 pizza: ", font = "10")
pizzalbl.place(x = 10, y = 100)
pizzaetr = Entry(screen, textvariable = pizzav)
pizzaetr.place(x = 95, y = 100)

pastav = IntVar()
pastalbl = Label(screen, text = "t100 pasta: ", font = "10")
pastalbl.place(x = 10, y = 130)
pastaetr = Entry(screen, textvariable = pastav)
pastaetr.place(x = 95, y = 130)

saladv = IntVar()
saladlbl = Label(screen, text = "t100 salad: ", font = "10")
saladlbl.place(x = 10, y = 160)
saladetr = Entry(screen, textvariable = saladv)
saladetr.place(x = 95, y = 160)

sandwichv = IntVar()
sandwichlbl = Label(screen, text = "t150 sandwich: ", font = "10")
sandwichlbl.place(x = 10, y = 190)
sandwichetr = Entry(screen, textvariable = sandwichv)
sandwichetr.place(x = 120, y = 190)

btnserv = Button(screen, text = "ENTER", command = serv)
btnserv.place(x = 130, y = 240)



screen.mainloop()