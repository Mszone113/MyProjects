from sqlalchemy import create_engine, Column, String, TEXT, Integer
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import session, sessionmaker
from tkinter import *
from tkinter import messagebox


engine = create_engine("sqlite:///foroshdb.db", echo=True)
Base = declarative_base()
Sessions = sessionmaker(bind=engine)

sessinon = Sessions()


class kafsh(Base):
    __tablename__ = "kafsh"
    id = Column(Integer, primary_key=True)
    model = Column(String)
    size = Column(Integer)

    def __init__(self, model="", size = ""):
        self.model = model
        self.size = size


class kif(Base):
    __tablename__ = "kif"
    id = Column(Integer, primary_key=True)
    model = Column(String)

    def __init__(self, model=""):
        self.model = model


class Repository():
    def Add(self, obj):
        sessinon.add(obj)
        sessinon.commit()

    def selectAll(self, obj):
        result = sessinon.query(obj).all()
        return result

    def selectById(self, obj, id):
        result = sessinon.query(obj).filter(obj.id == id).first()
        return result

    def showObj(self, list, index):
        for item in list:
            atr = getattr(item, index)
            print(atr)

    def update(self, id, object, **kwargs):
        record = self.selectById(object, id)
        for key, val in kwargs.items():
            setattr(record, key, val)
        sessinon.commit()

    def delete(self, id, object):
        record = self.selectById(object, id)
        sessinon.delete(record)
        sessinon.commit()


Base.metadata.create_all(engine)

repos = Repository()


screen = Tk()

screen.geometry("%dx%d+%d+%d" % (700, 400, 300, 200))
screen.title("Foroshgah Kif o Kafsh Mardane  1.0.0")
screen.resizable(False, False)



kafsh_edari2 = PhotoImage(file = "kafsh2.png")
kif_edari2 = PhotoImage(file = "edari2.png")
kif_madrese2 = PhotoImage(file = "madreseh2.png")
kif_edari = PhotoImage(file = "edari.png")
kafsh_edari = PhotoImage(file = "kafsh.png")
kif_madrese = PhotoImage(file = "madreseh.png")
kafsh_sport = PhotoImage(file = "shoes.png")
kafsh_sport2 = PhotoImage(file = "shoes2.png")
def upfrmkif():
    frmkif.place(x= 0, y = 0)


def gomadrese():
    frmkifmadrese.place(x = 0, y = 0)

def goedari():
    frmkifedari.place(x = 0, y = 0)

def gosport():
    frmkafshsport.place(x = 0, y = 0)

def gomajlesi():
    frmkafshmajlesi.place(x= 0 , y = 0)

def buy():
    khe = kif(model="kif")
    repos.Add(khe)
    messagebox.showinfo("thanks", "added to basket")


def buykafsh():
    kh = kafsh(model = "kafsh", size= "free")
    repos.Add(kh)
    messagebox.showinfo("thanks", "added to basket")


def upfrmkafsh():
    frmkafsh.place(x= 0, y = 0)

lblkif = Button(screen, image = kif_edari, command = upfrmkif)
lblkif.pack(side = "left")

lblkafsh = Button(screen, image= kafsh_edari, command = upfrmkafsh)
lblkafsh.pack(side = "right")




frmkif = Frame(screen, height = 400, width = 700)
frmkif.place(x = 0, y = 0)
frmkif.place_forget()

btnkifmadrese = Button(frmkif, image = kif_madrese, command = gomadrese)
btnkifmadrese.place(x = 0, y = 0)

btnkifedari = Button(frmkif, image = kif_edari, command = goedari)
btnkifedari.place(x = 400, y = 0)

lblmadrese = Label(frmkif, text = "Madrese", font = 10)
lblmadrese.place(x=100, y = 300)

lbledari = Label(frmkif, text = " Edari", font = 10)
lbledari.place(x=500, y = 300)


frmkafsh = Frame(screen, height = 400, width = 700)
frmkafsh.place(x = 0, y = 0)
frmkafsh.place_forget()

btnkafshmajlesi = Button(frmkafsh, image = kafsh_sport, command = gosport)
btnkafshmajlesi.place(x = 0, y = 50)

btnkafshsport = Button(frmkafsh, image = kafsh_edari, command = gomajlesi)
btnkafshsport.place(x = 400, y = 0)

lblmajlesi = Label(frmkafsh, text = "Sport", font = 10)
lblmajlesi.place(x=100, y = 300)

lblsport = Label(frmkafsh, text = "Majlesi", font = 10)
lblsport.place(x=500, y = 300)

#-------------------kif ha---------------------

frmkifmadrese = Frame(screen, height = 400, width = 700)


btnkifmadrese1 = Label(frmkifmadrese, image = kif_madrese2)
btnkifmadrese1.place(x = 0, y = 0)

btnkifmadrese2 = Label(frmkifmadrese, image = kif_madrese)
btnkifmadrese2.place(x = 400, y = 0)



a = """
model: a121
color: Blue
price: 210$
"""

b = """
model: a134
color: Black
price: ---
"""

lblmadrese1 = Label(frmkifmadrese, text = a, font = 10)
lblmadrese1.place(x=100, y = 270)



lblmadrese1 = Button(frmkifmadrese, text = "buy", font = 10, command= buy)
lblmadrese1.place(x=50, y = 290)



lblmadrese2 = Label(frmkifmadrese, text = b, font = 10)
lblmadrese2.place(x=500, y = 280)



frmkifedari = Frame(screen, height = 400, width = 700)


btnkifedari = Label(frmkifedari, image = kif_edari2)
btnkifedari.place(x = 0, y = 0)

btnkifedari2 = Label(frmkifedari, image = kif_edari)
btnkifedari2.place(x = 400, y = 0)

a = """
model: a253
color: Blue
price: 210$
"""
b = """
model: a245
color: Black
price: ---
"""

lblmadrese1 = Label(frmkifedari, text = a, font = 10)
lblmadrese1.place(x=100, y = 270)

lblmadrese1 = Button(frmkifedari, text = "buy", font = 10, command= buy)
lblmadrese1.place(x=50, y = 290)

lblmadrese2 = Label(frmkifedari, text = b, font = 10)
lblmadrese2.place(x=500, y = 280)


#-----------------kafsh-------------------

frmkafshsport = Frame(screen, height = 400, width = 700)


btnkafshsport = Label(frmkafshsport, image = kafsh_sport2)
btnkafshsport.place(x = 0, y = 0)

btnkafshsport2 = Label(frmkafshsport, image = kafsh_sport)
btnkafshsport2.place(x = 400, y = 0)

a = """
model: a653
color: Black
price: 130$
"""
b = """
model: a646
color: Black
price: ---
"""


lblsport1 = Label(frmkafshsport, text = a, font = 10)
lblsport1.place(x=100, y = 270)

lblsport1 = Button(frmkafshsport, text = "buy", font = 10, command= buykafsh)
lblsport1.place(x=50, y = 290)

lblma2 = Label(frmkafshsport, text = b, font = 10)
lblma2.place(x=500, y = 280)




frmkafshmajlesi = Frame(screen, height = 400, width = 700)


btnkafshmajlesi = Label(frmkafshmajlesi, image = kafsh_edari)
btnkafshmajlesi.place(x = 0, y = 0)

btnkafshmajlesi2 = Label(frmkafshmajlesi, image = kafsh_edari2)
btnkafshmajlesi2.place(x = 400, y = 0)

a = """
model: a653
color: Black
price: 130$
"""
b = """
model: a646
color: Black
price: ---
"""


lblmajlesi1 = Label(frmkafshmajlesi, text = a, font = 10)
lblmajlesi1.place(x=100, y = 270)

lblmajlesi1 = Button(frmkafshmajlesi, text = "buy", font = 10, command= buykafsh)
lblmajlesi1.place(x=50, y = 290)

lblma2 = Label(frmkafshmajlesi, text = b, font = 10)
lblma2.place(x=500, y = 280)


screen.mainloop()
