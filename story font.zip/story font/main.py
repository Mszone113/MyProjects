from tkinter import *
from tkinter import ttk
screen = Tk()

screen.geometry("%dx%d+%d+%d" % (600, 300, 150, 100))
screen.title("FontEditor   1.0.0")
screen.resizable(False, False)
screen.iconbitmap("img/F.ico")






def aviny():
    lblfont.configure(font = "Aviny.ttf")

def bahman():
    lblfont.configure(font = "Bahman.ttf")

def colak():
    lblfont.configure(font = "Colak.ttf")

def fedra():
    lblfont.configure(font = "Fedra.ttf")

def kalame():
    lblfont.configure(font = "Kalameh.ttf")

def lalezar():
    lblfont.configure(font = "Lalezar.ttf")


def blue():
    lblfont.configure(fg = "blue")

def red():
    lblfont.configure(fg = "red")

def black():
    lblfont.configure(fg = "black")

def yellow():
    lblfont.configure(fg = "yellow")

def green():
    lblfont.configure(fg = "green")

def magenta():
    lblfont.configure(fg = "magenta")






lblfont = Label(screen, text = "Enter Your Text", font = 40).place(x = 250, y = 100)

btnfont1 = Button(screen, text = "Aviny", width = 4, height = 2, command = aviny).place(x = 0, y = 30)

btnfont2 = Button(screen, text = "Bahman", width = 5, height = 2, command = bahman).place(x = 0, y = 70)

btnfont3 = Button(screen, text = "Colak", width = 4, height = 2, command = colak).place(x = 0, y = 110)

btnfont4 = Button(screen, text = "Fedra", width = 4, height = 2, command = fedra).place(x = 0, y = 150)

btnfont5 = Button(screen, text = "Kalame", width = 5, height = 2, command = kalame).place(x = 0, y = 190)

btnfont6 = Button(screen, text = "LaleZar", width = 6, height = 2, command = lalezar).place(x = 0, y = 220)

lblfonts = Label(screen, text = "Fonts:", font = 25).place(x = 0, y = 0)




btnfont1 = Button(screen, text = "blue", width = 4, height = 2, command = blue).place(x = 530, y = 30)

btnfont2 = Button(screen, text = "red", width = 5, height = 2, command = red).place(x = 530, y = 70)

btnfont3 = Button(screen, text = "black", width = 4, height = 2, command = black).place(x = 530, y = 110)

btnfont4 = Button(screen, text = "yellow", width = 4, height = 2, command = yellow).place(x = 530, y = 150)

btnfont5 = Button(screen, text = "green", width = 5, height = 2, command = green).place(x = 530, y = 190)

btnfont6 = Button(screen, text = "magenta", width = 6, height = 2, command = magenta).place(x = 530, y = 230)

lblfonts = Label(screen, text = "Colors:", font = 25).place(x = 530, y = 0)




screen.mainloop()