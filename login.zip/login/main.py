from tkinter import *

from tkinter import messagebox

screen = Tk()

screen.geometry("%dx%d+%d+%d" % (300, 400, 150, 100))
screen.title("LoginUniversity   1.0.0")
screen.resizable(False, False)
screen.iconbitmap("img/icon.ico")


def clickenter():
    n = namev.get()
    f = familyv.get()
    a = agev.get()
    s = studyv.get()
    c = codemeliv.get()
    j = jensv.get()

    if j == 0:
        if n == "" or f == "" or  a < 18 or s == "" or c == 0:
            messagebox.showerror("خطا", "لطفا مشخصات را وارد کنید")
        else:
            b = "اقای" + n + " " + f + " " + "با موفقیت ثبت نام شد"
            messagebox.showinfo("خوش آمدید", b)
            screen.quit()
            n = namev.set("")
            f = familyv.set("")
            a = agev.set("")
            s = studyv.set("")
            c = codemeliv.set("")

    if j == 1:
        if n == "" or f == "" or  a < 18 or s == "" or c == 0:
            messagebox.showerror("خطا", "لطفا مشخصات را وارد کنید")
        else:
            b = "خانوم" + n + " " + f + " " + "با موفقیت ثبت نام شد"
            messagebox.showinfo("خوش آمدید", b)
            screen.quit()
        n = namev.set("")
        f = familyv.set("")
        a = agev.set("")
        s = studyv.set("")
        c = codemeliv.set("")




namev = StringVar()
familyv = StringVar()
agev = IntVar()
studyv = StringVar()
codemeliv = IntVar()
jensv = IntVar()

lblname = Label(screen, text= "نام").pack()
txtname = Entry(screen, justify = "center", textvariable= namev).pack()

lblname = Label(screen, text= "نام خوانوادگی").pack()
txtname = Entry(screen, justify = "center", textvariable= familyv).pack()

lblname = Label(screen, text= "سن").pack()
txtname = Entry(screen, justify = "center", textvariable= agev).pack()

lblname = Label(screen, text= "رشته تحصیلی").pack()
txtname = Entry(screen, justify = "center", textvariable= studyv).pack()

lblname = Label(screen, text= "کد ملی").pack()
txtname = Entry(screen, justify = "center", textvariable= codemeliv).pack()

lbljens = Label(screen, text= "جنسیت").pack()
etrjens = Radiobutton(screen, text = "مرد", variable = jensv, value=0).pack()
etrjens = Radiobutton(screen, text = "زن", variable = jensv, value=1).pack()

btnenter = Button(screen, text = "ثبت / ورود", command = clickenter).pack()

screen.mainloop()